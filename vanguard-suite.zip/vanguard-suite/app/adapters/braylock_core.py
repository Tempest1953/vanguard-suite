class BraylockCoreAdapter:
    PRODUCTS = {
        "CFOCore": {"persona":"CFO/CIO", "roi":"Forecasting, compliance, FX risk."},
        "SentientX": {"persona":"CEO/COO", "roi":"Executive intelligence layer."},
        "EchelonNexus": {"persona":"CTO/PE", "roi":"Agent mesh + digital twin."},
    }
    def angle(self, product: str, company: dict) -> str:
        meta = self.PRODUCTS.get(product, {"roi":"AI outcomes"})
        return f"{product}: {meta['roi']} @ {company['name']}"

ADAPTER = BraylockCoreAdapter()
