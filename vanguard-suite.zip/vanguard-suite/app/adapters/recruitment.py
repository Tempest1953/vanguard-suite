class RecruitmentAdapter:
    def client_angle(self, company: dict) -> str:
        return "Fill senior commercial counsel 30% faster with validated LexiPersona talent"
    def candidate_angle(self, company: dict) -> str:
        return "Top-tier role fit using semantic vector matching and LexGPT briefing"

RECRUIT_ADAPTER = RecruitmentAdapter()
