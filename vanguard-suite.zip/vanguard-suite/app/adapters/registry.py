class AdapterRegistry:
    def __init__(self):
        self.adapters = {}
    def register(self, key: str, adapter: object):
        self.adapters[key] = adapter
    def get(self, key: str):
        return self.adapters.get(key)

REGISTRY = AdapterRegistry()
