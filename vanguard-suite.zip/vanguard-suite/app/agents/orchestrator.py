from .base import Agent

class Orchestrator(Agent):
    name = "VanguardOrchestrator"
    async def handle(self, event):
        return []
