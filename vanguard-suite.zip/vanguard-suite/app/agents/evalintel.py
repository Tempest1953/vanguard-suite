from .base import Agent

class EvalIntelBot(Agent):
    name = "EvalIntelBot"
    async def handle(self, event):
        if event["type"] == "SEQUENCE_SENT":
            self.hub.db.increment("sends")
        if event["type"] == "REPLY_RECEIVED":
            self.hub.db.increment("replies_total")
        return []
