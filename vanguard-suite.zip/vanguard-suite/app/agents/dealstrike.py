from .base import Agent
from app.utils.emailer import MAIL

class DealStrikeBot(Agent):
    name = "DealStrikeBot"
    async def handle(self, event):
        out = []
        if event["type"] == "LEAD_READY_FOR_OUTREACH":
            contact = event["payload"]["contact"]
            subject = event["payload"].get("subject", "Quick idea")
            template = event["payload"]["template"]
            body = template.format(**contact)
            msg_id = MAIL.send(contact["email"], subject, body)
            self.hub.db.log_event("SEQUENCE_SENT", {"msg_id": msg_id, "contact_id": contact["id"]})
            out.append({"type": "FOLLOWUP_SCHEDULED", "payload": {"contact_id": contact["id"], "days": 3}})
        if event["type"] == "REPLY_RECEIVED":
            txt = event["payload"]["text"].lower()
            label = "positive" if any(k in txt for k in ["call","interested","yes","schedule"]) else "negative"
            self.hub.db.update_contact_status(event["payload"]["contact_id"], label)
            if label == "positive":
                out.append({"type": "BOOK_MEETING", "payload": {"contact_id": event["payload"]["contact_id"]}})
        return out
